# blog_api

Simple blog API

## Setup
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt


# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver
```

## API Endpoints

- `GET /api/user` - List all User
- `GET /api/user/{id}` - Get User by ID
- `POST /api/user` - Create User
- `PUT /api/user/{id}` - Update User
- `DELETE /api/user/{id}` - Delete User

- `GET /api/post` - List all Post
- `GET /api/post/{id}` - Get Post by ID
- `POST /api/post` - Create Post
- `PUT /api/post/{id}` - Update Post
- `DELETE /api/post/{id}` - Delete Post


