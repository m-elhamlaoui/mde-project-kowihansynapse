from django.db import models
import uuid

class User(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(max_length=254)
    createdat = models.DateTimeField()

    class Meta:
        db_table = 'users'

    def __str__(self):
        return f"User {self.id}"
