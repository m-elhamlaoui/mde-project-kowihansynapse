from django.db import models
import uuid

class Post(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=255)
    content = models.TextField()
    createdat = models.DateTimeField()
    author = models.ForeignKey('User', on_delete=models.CASCADE)

    class Meta:
        db_table = 'posts'

    def __str__(self):
        return f"Post {self.id}"
