from django.contrib import admin
from .models.user import User
from .models.post import Post

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'email']
    search_fields = ['email']

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'content']
    search_fields = ['title', 'content']

