from rest_framework import viewsets, filters
from django_filters.rest_framework import DjangoFilterBackend
from ..models import User
from ..serializers  import UserSerializer

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = '__all__'
    search_fields = ['email']
    ordering_fields = '__all__'
