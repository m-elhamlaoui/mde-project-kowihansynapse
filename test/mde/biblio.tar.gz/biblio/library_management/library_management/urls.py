from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views.member_viewset import MemberViewSet
from .views.author_viewset import AuthorViewSet
from .views.category_viewset import CategoryViewSet
from .views.book_viewset import BookViewSet
from .views.loan_viewset import LoanViewSet
from .views.reservation_viewset import ReservationViewSet

from .views.borrowbook_view import borrowbook_view

from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

router = DefaultRouter()
router.register(r'member', MemberViewSet)
router.register(r'author', AuthorViewSet)
router.register(r'category', CategoryViewSet)
router.register(r'book', BookViewSet)
router.register(r'loan', LoanViewSet)
router.register(r'reservation', ReservationViewSet)

interaction_patterns = [
    path('api/loans/borrow', borrowbook_view, name='borrowbook'),
]

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
        path('', include((interaction_patterns, 'interactions'), namespace='interactions')),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('swagger/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]

from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns += [
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
