from django.db import models
import uuid

class Author(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    biography = models.TextField(null=True, blank=True)
    birthdate = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, null=True, blank=True)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()

    class Meta:
        db_table = 'authors'

    def __str__(self):
        return f"Author {self.id}"
