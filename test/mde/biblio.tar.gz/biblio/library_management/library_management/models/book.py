from django.db import models
import uuid

class Book(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    isbn = models.CharField(max_length=13)
    title = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    publisheddate = models.DateField(null=True, blank=True)
    publisher = models.CharField(max_length=100, null=True, blank=True)
    pagecount = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20)
    location = models.CharField(max_length=100, null=True, blank=True)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()
    authors = models.ManyToManyField('Author')
    category = models.ForeignKey('Category', on_delete=models.SET_NULL, null=True, blank=True, related_name='books')

    class Meta:
        db_table = 'books'

    def __str__(self):
        return f"Book {self.id}"
