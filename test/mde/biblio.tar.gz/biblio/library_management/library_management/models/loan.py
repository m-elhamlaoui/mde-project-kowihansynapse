from django.db import models
import uuid

class Loan(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    loandate = models.DateField()
    duedate = models.DateField()
    returndate = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20)
    latefee = models.DecimalField(max_digits=10, decimal_places=2)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()
    member = models.ForeignKey('Member', on_delete=models.PROTECT, related_name='loans')
    book = models.ForeignKey('Book', on_delete=models.PROTECT, related_name='loans')

    class Meta:
        db_table = 'loans'

    def __str__(self):
        return f"Loan {self.id}"
