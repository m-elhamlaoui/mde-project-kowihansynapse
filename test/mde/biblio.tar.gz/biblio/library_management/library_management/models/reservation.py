from django.db import models
import uuid

class Reservation(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reservationdate = models.DateField()
    expirydate = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()
    member = models.ForeignKey('Member', on_delete=models.CASCADE, related_name='reservations')
    book = models.ForeignKey('Book', on_delete=models.CASCADE, related_name='reservations')

    class Meta:
        db_table = 'reservations'

    def __str__(self):
        return f"Reservation {self.id}"
