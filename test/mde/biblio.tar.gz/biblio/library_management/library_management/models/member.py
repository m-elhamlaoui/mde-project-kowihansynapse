from django.db import models
import uuid

class Member(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    memberid = models.CharField(max_length=20)
    firstname = models.CharField(max_length=150)
    lastname = models.CharField(max_length=150)
    email = models.EmailField(max_length=254)
    phone = models.CharField(max_length=20, null=True, blank=True)
    joindate = models.DateField()
    status = models.CharField(max_length=20)
    maxloans = models.IntegerField()
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()

    class Meta:
        db_table = 'members'

    def __str__(self):
        return f"Member {self.id}"
