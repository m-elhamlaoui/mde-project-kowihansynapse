from django.apps import AppConfig

class library_managementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'library_management'
