from django.contrib import admin
from .models.member import Member
from .models.author import Author
from .models.category import Category
from .models.book import Book
from .models.loan import Loan
from .models.reservation import Reservation

@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ['id', 'memberid', 'firstname', 'lastname', 'email', 'phone', 'status']
    search_fields = ['memberid', 'firstname', 'lastname', 'email', 'phone', 'status']

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'biography', 'nationality']
    search_fields = ['name', 'biography', 'nationality']

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'description']
    search_fields = ['name', 'description']

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['id', 'isbn', 'title', 'description', 'publisher', 'status', 'location']
    search_fields = ['isbn', 'title', 'description', 'publisher', 'status', 'location']

@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ['id', 'status']
    search_fields = ['status']

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ['id', 'status']
    search_fields = ['status']

