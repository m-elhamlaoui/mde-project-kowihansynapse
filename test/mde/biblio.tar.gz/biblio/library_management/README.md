# library_management

Library management system with books, authors, members, loans and reservations

## Setup
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt


# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver
```

## API Endpoints

- `GET /api/member` - List all Member
- `GET /api/member/{id}` - Get Member by ID
- `POST /api/member` - Create Member
- `PUT /api/member/{id}` - Update Member
- `DELETE /api/member/{id}` - Delete Member

- `GET /api/author` - List all Author
- `GET /api/author/{id}` - Get Author by ID
- `POST /api/author` - Create Author
- `PUT /api/author/{id}` - Update Author
- `DELETE /api/author/{id}` - Delete Author

- `GET /api/category` - List all Category
- `GET /api/category/{id}` - Get Category by ID
- `POST /api/category` - Create Category
- `PUT /api/category/{id}` - Update Category
- `DELETE /api/category/{id}` - Delete Category

- `GET /api/book` - List all Book
- `GET /api/book/{id}` - Get Book by ID
- `POST /api/book` - Create Book
- `PUT /api/book/{id}` - Update Book
- `DELETE /api/book/{id}` - Delete Book

- `GET /api/loan` - List all Loan
- `GET /api/loan/{id}` - Get Loan by ID
- `POST /api/loan` - Create Loan
- `PUT /api/loan/{id}` - Update Loan
- `DELETE /api/loan/{id}` - Delete Loan

- `GET /api/reservation` - List all Reservation
- `GET /api/reservation/{id}` - Get Reservation by ID
- `POST /api/reservation` - Create Reservation
- `PUT /api/reservation/{id}` - Update Reservation
- `DELETE /api/reservation/{id}` - Delete Reservation


- `POST /api/loans/borrow` - Member borrows a book with validation checks
