from django.db import models
import uuid

class Order(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ordernumber = models.CharField(max_length=50)
    status = models.CharField(max_length=20)
    totalamount = models.DecimalField(max_digits=10, decimal_places=2)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()
    customer = models.ForeignKey('User', on_delete=models.PROTECT, related_name='orders')

    class Meta:
        db_table = 'orders'

    def __str__(self):
        return f"Order {self.id}"
