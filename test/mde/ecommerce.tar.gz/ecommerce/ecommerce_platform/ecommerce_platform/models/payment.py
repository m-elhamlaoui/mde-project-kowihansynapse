from django.db import models
import uuid

class Payment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transactionid = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    method = models.CharField(max_length=20)
    status = models.CharField(max_length=20)
    createdat = models.DateTimeField()
    order = models.OneToOneField('Order', on_delete=models.CASCADE, related_name='payment')

    class Meta:
        db_table = 'payments'

    def __str__(self):
        return f"Payment {self.id}"
