from django.db import models
import uuid

class Vendor(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    storename = models.CharField(max_length=255)
    storedescription = models.TextField(null=True, blank=True)
    commissionrate = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()
    user = models.OneToOneField('User', on_delete=models.CASCADE, related_name='vendorProfile')

    class Meta:
        db_table = 'vendors'

    def __str__(self):
        return f"Vendor {self.id}"
