from django.db import models
import uuid

class User(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(max_length=254)
    firstname = models.CharField(max_length=150)
    lastname = models.CharField(max_length=150)
    usertype = models.CharField(max_length=20)
    isactive = models.BooleanField(default=False)
    createdat = models.DateTimeField()
    updatedat = models.DateTimeField()

    class Meta:
        db_table = 'users'

    def __str__(self):
        return f"User {self.id}"
