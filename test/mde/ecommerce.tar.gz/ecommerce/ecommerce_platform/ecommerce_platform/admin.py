from django.contrib import admin
from .models.user import User
from .models.vendor import Vendor
from .models.product import Product
from .models.order import Order
from .models.orderitem import OrderItem
from .models.payment import Payment

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'email', 'firstname', 'lastname', 'usertype']
    list_filter = ['isactive']
    search_fields = ['email', 'firstname', 'lastname', 'usertype']

@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ['id', 'storename', 'storedescription', 'status']
    search_fields = ['storename', 'storedescription', 'status']

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'sku', 'name', 'slug', 'description']
    list_filter = ['isactive']
    search_fields = ['sku', 'name', 'slug', 'description']

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'ordernumber', 'status']
    search_fields = ['ordernumber', 'status']

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['id']

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['id', 'transactionid', 'method', 'status']
    search_fields = ['transactionid', 'method', 'status']

