from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views.user_viewset import UserViewSet
from .views.vendor_viewset import VendorViewSet
from .views.product_viewset import ProductViewSet
from .views.order_viewset import OrderViewSet
from .views.orderitem_viewset import OrderItemViewSet
from .views.payment_viewset import PaymentViewSet

from .views.processorder_view import processorder_view

from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

router = DefaultRouter()
router.register(r'user', UserViewSet)
router.register(r'vendor', VendorViewSet)
router.register(r'product', ProductViewSet)
router.register(r'order', OrderViewSet)
router.register(r'orderitem', OrderItemViewSet)
router.register(r'payment', PaymentViewSet)

interaction_patterns = [
    path('api/orders/process', processorder_view, name='processorder'),
]

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
        path('', include((interaction_patterns, 'interactions'), namespace='interactions')),
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('swagger/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]

from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns += [
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
