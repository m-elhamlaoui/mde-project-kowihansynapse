# ecommerce_platform

Multi-vendor e-commerce platform with inventory management

## Setup
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt


# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Run server
python manage.py runserver
```

## API Endpoints

- `GET /api/user` - List all User
- `GET /api/user/{id}` - Get User by ID
- `POST /api/user` - Create User
- `PUT /api/user/{id}` - Update User
- `DELETE /api/user/{id}` - Delete User

- `GET /api/vendor` - List all Vendor
- `GET /api/vendor/{id}` - Get Vendor by ID
- `POST /api/vendor` - Create Vendor
- `PUT /api/vendor/{id}` - Update Vendor
- `DELETE /api/vendor/{id}` - Delete Vendor

- `GET /api/product` - List all Product
- `GET /api/product/{id}` - Get Product by ID
- `POST /api/product` - Create Product
- `PUT /api/product/{id}` - Update Product
- `DELETE /api/product/{id}` - Delete Product

- `GET /api/order` - List all Order
- `GET /api/order/{id}` - Get Order by ID
- `POST /api/order` - Create Order
- `PUT /api/order/{id}` - Update Order
- `DELETE /api/order/{id}` - Delete Order

- `GET /api/orderitem` - List all OrderItem
- `GET /api/orderitem/{id}` - Get OrderItem by ID
- `POST /api/orderitem` - Create OrderItem
- `PUT /api/orderitem/{id}` - Update OrderItem
- `DELETE /api/orderitem/{id}` - Delete OrderItem

- `GET /api/payment` - List all Payment
- `GET /api/payment/{id}` - Get Payment by ID
- `POST /api/payment` - Create Payment
- `PUT /api/payment/{id}` - Update Payment
- `DELETE /api/payment/{id}` - Delete Payment


- `POST /api/orders/process` - Process complete order with payment and inventory update
