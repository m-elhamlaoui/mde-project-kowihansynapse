# personal_blog_application

## Description
Personal Blog Application

## Technologies
- **Framework**: Django
- **Base de données**: PostgreSQL
- **Entités**: User
- **Relations**: 5 relation(s) détectée(s)
- **Endpoints**: 16 endpoint(s) générés

## Installation

### 1. Créer un environnement virtuel:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate   # Windows
```

### 2. Installer les dépendances:
```bash
pip install -r requirements.txt
```

### 3. Configurer l'environnement:
```bash
cp .env.example .env
# Éditer .env avec vos paramètres
```

### 4. Initialiser la base de données:
```bash
python manage.py makemigrations
python manage.py migrate

```

### 5. Créer un superutilisateur (Django):
```bash
python manage.py createsuperuser
```

### 6. Lancer l'application:
```bash
python manage.py runserver
```

## Architecture

### Entités

**User**⭐ (User Model):
- username (string)
- email (email)
- password_hash (password)
- bio (text)
- avatar (image)
- is_active (boolean)
- created_at | Post: title (datetime)
- slug (string)
- content (text)
- excerpt (string)
- published_at (datetime)
- view_count (integer)
- featured (string)
- user_id | Comment: content (integer) → User
- created_at (datetime)
- user_id (integer) → User
- post_id (integer) → Post
- parent_comment_id | Tag: name (integer) → Parent_comment
- slug | PostTag: post_id (integer)
- tag_id (integer) → Tag

### Relations
- User → User (ForeignKey)
- User → User (ForeignKey)
- User → Post (ForeignKey)
- User → Parent_comment (ForeignKey)
- User → Tag (ForeignKey)

## API Endpoints


### USERS
- `GET` `/api/users` 🔒 - Liste tous les users
- `POST` `/api/users` 🔒 - Crée un nouveau User
- `GET` `/api/users/<id>` 🔓 - Récupère un User spécifique
- `PUT` `/api/users/<id>` 🔒 - Met à jour un User
- `PATCH` `/api/users/<id>` 🔒 - Met à jour partiellement un User
- `DELETE` `/api/users/<id>` 🔒 - Supprime un User
- `GET` `/api/users/<id>/users` 🔓 - Récupère tous les users d'un User
- `GET` `/api/users/<id>/users` 🔓 - Récupère tous les users d'un User
- `GET` `/api/users/<id>/posts` 🔓 - Récupère tous les posts d'un User
- `GET` `/api/users/<id>/parent_comments` 🔓 - Récupère tous les parent_comments d'un User
- `GET` `/api/users/<id>/tags` 🔓 - Récupère tous les tags d'un User

### AUTH
- `POST` `/api/auth/register` 🔓 - Inscription utilisateur
- `POST` `/api/auth/login` 🔓 - Connexion utilisateur
- `POST` `/api/auth/logout` 🔒 - Déconnexion utilisateur
- `GET` `/api/auth/me` 🔒 - Profil utilisateur courant
- `POST` `/api/auth/refresh` 🔒 - Rafraîchir le token

## Structure du projet
```
personal_blog_application/
├── personal_blog_application/
│   ├── models/
│   ├── views/
│   ├── serializers/
│   └── settings.py
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```

## Tests

```bash
python manage.py test
```

## Documentation API

Django Admin: http://localhost:8000/admin/
API Documentation: http://localhost:8000/api/schema/swagger-ui/

## Sécurité

- Les mots de passe sont hashés avec bcrypt
- JWT pour l'authentification
- CORS configuré
- Variables d'environnement pour les secrets

## Licence
MIT
