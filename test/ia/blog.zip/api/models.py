from django.db import models
from django.contrib.auth.hashers import make_password, check_password



class User(models.Model):
    """Model pour User"""
    username = models.CharField(max_length=255, unique=True)
    email = models.EmailField(unique=True)
    password_hash = models.CharField(max_length=255)
    bio = models.TextField()
    avatar = models.ImageField(upload_to="images/")
    is_active = models.BooleanField(default=False)
    created_at | Post: title = models.DateTimeField()
    slug = models.CharField(max_length=255, unique=True)
    content = models.TextField()
    excerpt = models.CharField(max_length=255)
    published_at = models.DateTimeField()
    view_count = models.IntegerField()
    featured = models.CharField(max_length=255)
    user_id | Comment: content = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    created_at = models.DateTimeField()
    user_id = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    post_id = models.ForeignKey(
        'Post',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    parent_comment_id | Tag: name = models.ForeignKey(
        'Parent_comment',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    slug | PostTag: post_id = models.IntegerField()
    tag_id = models.ForeignKey(
        'Tag',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['-created_at']

    def __str__(self):
        return self.username

    def set_password(self, raw_password):
        """Hash et définit le mot de passe"""
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        """Vérifie le mot de passe"""
        return check_password(raw_password, self.password)