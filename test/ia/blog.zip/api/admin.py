from django.contrib import admin
from .models import User


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'email', 'password_hash', 'bio', 'avatar', 'created_at', 'updated_at']
    search_fields = ['username', 'email', 'bio']
    list_filter = ['created_at']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']