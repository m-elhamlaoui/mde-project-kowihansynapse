from django.db import models
from django.contrib.auth.hashers import make_password, check_password



class User(models.Model):
    """Model pour User"""
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    role | Vendor: name = models.CharField(max_length=255)
    description = models.TextField()
    commission_rate = models.CharField(max_length=255)
    rating = models.IntegerField()
    status | Product: title = models.CharField(max_length=255)
    sku = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.IntegerField()
    description = models.TextField()
    category_id = models.ForeignKey(
        'Category',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    vendor_id | Category: name = models.ForeignKey(
        'Vendor',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    slug = models.CharField(max_length=255, unique=True)
    description | Order: total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=255)
    shipping_address = models.CharField(max_length=255)
    payment_method = models.CharField(max_length=255)
    user_id = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    vendor_id | OrderItem: quantity = models.ForeignKey(
        'Vendor',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    price = models.DecimalField(max_digits=10, decimal_places=2)
    order_id = models.ForeignKey(
        'Order',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    product_id | Payment: amount = models.ForeignKey(
        'Product',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    status = models.CharField(max_length=255)
    payment_method = models.CharField(max_length=255)
    transaction_id = models.ForeignKey(
        'Transaction',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    order_id | Review: rating = models.ForeignKey(
        'Order',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    comment = models.CharField(max_length=255)
    user_id = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    product_id | Shipping: tracking_number = models.ForeignKey(
        'Product',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    carrier = models.CharField(max_length=255)
    status = models.CharField(max_length=255)
    estimated_delivery = models.CharField(max_length=255)
    order_id | Promotion: code = models.ForeignKey(
        'Order',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    discount_type = models.IntegerField()
    discount_value = models.IntegerField()
    valid_from = models.IntegerField()
    valid_to | Inventory: quantity = models.IntegerField()
    location = models.CharField(max_length=255)
    last_updated = models.DateTimeField()
    product_id = models.ForeignKey(
        'Product',
        on_delete=models.CASCADE,
        related_name='users',
        null=False
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    def set_password(self, raw_password):
        """Hash et définit le mot de passe"""
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        """Vérifie le mot de passe"""
        return check_password(raw_password, self.password)