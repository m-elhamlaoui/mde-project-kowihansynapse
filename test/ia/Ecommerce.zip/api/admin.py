from django.contrib import admin
from .models import User


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'email', 'phone', 'address', 'role | Vendor: name', 'created_at', 'updated_at']
    search_fields = ['name', 'email', 'phone', 'address', 'role | Vendor: name']
    list_filter = ['created_at']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']