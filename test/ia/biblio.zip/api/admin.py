from django.contrib import admin
from .models import Book


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'isbn', 'description', 'published_date', 'publisher', 'created_at', 'updated_at']
    search_fields = ['title', 'isbn', 'description', 'publisher']
    list_filter = ['created_at']
    date_hierarchy = 'created_at'
    ordering = ['-created_at']