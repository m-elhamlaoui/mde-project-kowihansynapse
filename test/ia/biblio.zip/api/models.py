from django.db import models



class Book(models.Model):
    """Model pour Book"""
    title = models.CharField(max_length=255)
    isbn = models.CharField(max_length=255)
    description = models.TextField()
    published_date = models.DateTimeField()
    publisher = models.CharField(max_length=255)
    page_count = models.IntegerField()
    status = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    created_at = models.DateTimeField()
    updated_at | Author: name = models.DateTimeField()
    biography = models.TextField()
    birth_date = models.DateTimeField()
    nationality = models.CharField(max_length=255)
    created_at = models.DateTimeField()
    updated_at | Category: name = models.DateTimeField()
    description = models.TextField()
    created_at | Member: member_id = models.IntegerField()
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=255)
    join_date = models.DateTimeField()
    status = models.CharField(max_length=255)
    max_loans = models.CharField(max_length=255)
    created_at = models.DateTimeField()
    updated_at | Loan: loan_date = models.DateTimeField()
    due_date = models.DateTimeField()
    return_date = models.DateTimeField()
    status = models.CharField(max_length=255)
    late_fee = models.CharField(max_length=255)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()
    member_id = models.ForeignKey(
        'Member',
        on_delete=models.CASCADE,
        related_name='books',
        null=False
    )
    book_id | Reservation: reservation_date = models.ForeignKey(
        'Book',
        on_delete=models.CASCADE,
        related_name='books',
        null=False
    )
    expiry_date = models.DateTimeField()
    status = models.CharField(max_length=255)
    created_at = models.DateTimeField()
    updated_at = models.DateTimeField()
    member_id = models.ForeignKey(
        'Member',
        on_delete=models.CASCADE,
        related_name='books',
        null=False
    )
    book_id = models.ForeignKey(
        'Book',
        on_delete=models.CASCADE,
        related_name='books',
        null=False
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'books'
        verbose_name = 'Book'
        verbose_name_plural = 'Books'
        ordering = ['-created_at']

    def __str__(self):
        return self.title