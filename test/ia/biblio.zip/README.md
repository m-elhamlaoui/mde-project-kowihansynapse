# library_management_system

## Description
Library Management System

## Technologies
- **Framework**: Django
- **Base de données**: PostgreSQL
- **Entités**: Book
- **Relations**: 4 relation(s) détectée(s)
- **Endpoints**: 10 endpoint(s) générés

## Installation

### 1. Créer un environnement virtuel:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate   # Windows
```

### 2. Installer les dépendances:
```bash
pip install -r requirements.txt
```

### 3. Configurer l'environnement:
```bash
cp .env.example .env
# Éditer .env avec vos paramètres
```

### 4. Initialiser la base de données:
```bash
python manage.py makemigrations
python manage.py migrate

```

### 5. Créer un superutilisateur (Django):
```bash
python manage.py createsuperuser
```

### 6. Lancer l'application:
```bash
python manage.py runserver
```

## Architecture

### Entités

**Book**:
- title (string)
- isbn (string)
- description (text)
- published_date (datetime)
- publisher (string)
- page_count (integer)
- status (string)
- location (string)
- created_at (datetime)
- updated_at | Author: name (datetime)
- biography (text)
- birth_date (datetime)
- nationality (string)
- created_at (datetime)
- updated_at | Category: name (datetime)
- description (text)
- created_at | Member: member_id (integer)
- first_name (string)
- last_name (string)
- email (email)
- phone (string)
- join_date (datetime)
- status (string)
- max_loans (string)
- created_at (datetime)
- updated_at | Loan: loan_date (datetime)
- due_date (datetime)
- return_date (datetime)
- status (string)
- late_fee (string)
- created_at (datetime)
- updated_at (datetime)
- member_id (integer) → Member
- book_id | Reservation: reservation_date (integer) → Book
- expiry_date (datetime)
- status (string)
- created_at (datetime)
- updated_at (datetime)
- member_id (integer) → Member
- book_id (integer) → Book

### Relations
- Book → Member (ForeignKey)
- Book → Book (ForeignKey)
- Book → Member (ForeignKey)
- Book → Book (ForeignKey)

## API Endpoints


### BOOKS
- `GET` `/api/books` 🔓 - Liste tous les books
- `POST` `/api/books` 🔓 - Crée un nouveau Book
- `GET` `/api/books/<id>` 🔓 - Récupère un Book spécifique
- `PUT` `/api/books/<id>` 🔓 - Met à jour un Book
- `PATCH` `/api/books/<id>` 🔓 - Met à jour partiellement un Book
- `DELETE` `/api/books/<id>` 🔒 - Supprime un Book
- `GET` `/api/books/<id>/members` 🔓 - Récupère tous les members d'un Book
- `GET` `/api/books/<id>/books` 🔓 - Récupère tous les books d'un Book
- `GET` `/api/books/<id>/members` 🔓 - Récupère tous les members d'un Book
- `GET` `/api/books/<id>/books` 🔓 - Récupère tous les books d'un Book

## Structure du projet
```
library_management_system/
├── library_management_system/
│   ├── models/
│   ├── views/
│   ├── serializers/
│   └── settings.py
├── tests/
├── requirements.txt
├── .env.example
└── README.md
```

## Tests

```bash
python manage.py test
```

## Documentation API

Django Admin: http://localhost:8000/admin/
API Documentation: http://localhost:8000/api/schema/swagger-ui/

## Sécurité

- Les mots de passe sont hashés avec bcrypt
- JWT pour l'authentification
- CORS configuré
- Variables d'environnement pour les secrets

## Licence
MIT
