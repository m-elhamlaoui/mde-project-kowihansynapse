from .hotel import Hotel
from .room import Room
from .customer import Customer
from .booking import Booking
