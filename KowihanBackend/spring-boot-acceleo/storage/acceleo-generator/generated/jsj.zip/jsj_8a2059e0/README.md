# Generated Project

This project was generated using Kowihan API Generator.

**Note:** Full Acceleo integration requires the configured script.

To enable full generation:
1. Ensure the script (Python or Shell) is available
2. Configure acceleo.python.script in application.properties
3. For shell scripts: chmod +x script.sh

XMI Model used: model_7532457600704044864.xmi
